# Display

## About Display

### Overview

The Display Manager setting type controls the screen timeout value to conserve power. 

### Main Functionality

* Set the Screen Timeout Interval

##Parameter Notes

###Screen Timeout Interval
This feature sets how many seconds a device can be inactive before the screen turns off.


## Feature Compatibility
<iframe src="compare.html#mx=4.3&csp=DisplayMgr&os=All&embed=true"></iframe> 
