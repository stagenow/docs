# SdCard

## About SdCard

### Overview

The SdCard Manager setting type allows your application to manage the use of the device SD card.

### Main Functionality

* Enable/Disable SdCard


## Feature Compatibility
<iframe src="compare.html#mx=4.3&csp=SdCardMgr&os=All&embed=true"></iframe> 
