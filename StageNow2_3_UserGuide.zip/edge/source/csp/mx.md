# MX

## About MX

### Overview

### Main Functionality

* [List]


## Feature Compatibility

<table>
	<tr>
		<th>Parameters</th>
		<th>Specific</th>
		<th>MC32</th>
		<th>MC40</th>
		<th>MC67</th>
		<th>TC55</th>
		<th>TC70</th>

	</tr>

	<tr>
		<td rowspan="3">Parameter 1</td>
		<td>Setting 1</td>
		<td>X</td>
		<td>X</td>
		<td></td>
		<td></td>
		<td>X</td>
	</tr>	
	<tr>
		<td>Setting 2</td>
		<td>X</td>
		<td>X</td>
		<td></td>
		<td></td>
		<td>X</td>
	</tr>	
	<tr>
		<td>Setting 3</td>
		<td>X</td>
		<td>X</td>
		<td>X</td>
		<td>X</td>
		<td>X</td>
	</tr>	
	
	<tr>
		<td rowspan="3">Parameter 2</td>
		<td>Setting 1</td>
		<td>X</td>
		<td>X</td>
		<td></td>
		<td></td>
		<td>X</td>
	</tr>	
	<tr>
		<td>Setting 2</td>
		<td>X</td>
		<td>X</td>
		<td></td>
		<td></td>
		<td>X</td>
	</tr>	
	<tr>
		<td>Setting 3</td>
		<td>X</td>
		<td>X</td>
		<td>X</td>
		<td>X</td>
		<td>X</td>
	</tr>	


	<tr>
		<td rowspan="3">Parameter 3</td>
		<td>Setting 1</td>
		<td>X</td>
		<td>X</td>
		<td></td>
		<td></td>
		<td>X</td>
	</tr>	
	<tr>
		<td>Setting 2</td>
		<td>X</td>
		<td>X</td>
		<td></td>
		<td></td>
		<td>X</td>
	</tr>	
	<tr>
		<td>Setting 3</td>
		<td>X</td>
		<td>X</td>
		<td>X</td>
		<td>X</td>
		<td>X</td>
	</tr>	
</table>

## Queries

## Error Handling