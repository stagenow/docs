# Network.WLAN.Android.FusionOptions

## About Network.WLAN.Android.FusionOptions

### Overview
The Network.WLAN.Android setting type defines the WLAN settings on Android devices during staging.

### Main Functionality

* Allow setting 802.11d option. 
* Enable 802.11d.
* Allow user to select country code.
* Allow setting RF band.
