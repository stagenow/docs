# Network.WLAN.Android

## About Network.WLAN.Android

### Overview
The Network.WLAN.Android setting type configures the WLAN settings on Android devices.

### Main Functionality

* Disable all other profiles. 
* Allow setting an option for access point ESSID.
* Set network profile encryption.
