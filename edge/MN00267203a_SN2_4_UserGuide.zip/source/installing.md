# Installation

This section includes the hardware and software requirements for setting up the StageNow Staging Solution. 

## StageNow Workstation Requirements
Following are the minimum requirements for the host computer to run the StageNow Workstation Tool:

* Operating system: Microsoft Windows 7 (64 bit)

* Operating memory: 2 GB minimum

* Hard drive storage: 6 GB minimum (if .Net Framework is not already installed)

* Screen resolution: 1366 x 768 (16:9 ratio) recommended

* .Net Framework 4.5. 

* .Net 4.5.1 is included in the StageNow installation wizard if required, and also available at http://www.microsoft.com

* StageNow Workstation Tool installer, available at http://www.zebra.com/support

* A PDF reader for supporting staging material, Adobe® Acrobat® Reader recommended.

* Java Runtime (JRE) to use Audio staging

* Wireless network interface card to use the Wi-Fi Hotspot feature

 
![img](images/TroubleWifi_Error.jpg)

Following are actions you can take to resolve the issue.

### Disable and Re-enable the Wi-Fi Adapter

1. Right-click on the Network icon on the bottom right corner of the Windows host and select Open Network and Sharing Center to open the following screen.

   ![img](images/TroubleWifi_NWSharingCenter.jpg)

2. On the left pane, select Change adapter settings.

   ![img](images/TroubleWifi_ChangeSettings.jpg)

3. Open a command prompt and enter "netsh wlan show drivers" to find the Wi-Fi driver adapter name.

   ![img](images/TroubleWifi_CommandPrompt.jpg)

4. Right-click on the network adapter in the Network Connections window and select Disable. 

5. Right-click again and select Enable. After a few minutes, try using the StageNow Tool.

