# Setting Types

This section describes the parameters and values available when creating settings. 